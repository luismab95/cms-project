db = db.getSiblingDB("cms"); // Create or switch to 'mydatabase'

db.createUser({
  user: "cms",
  pwd: "FOFSADK93490DFSFads23",
  roles: [{ role: "readWrite", db: "cms" }],
});


